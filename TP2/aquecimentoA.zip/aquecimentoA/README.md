Sourdough: example classes for network programming

To build:

	$ ./autogen.sh
	$ ./configure
	$ make

